package com.daniella.eportfolio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EportfolioApplicationTests {

	@Test
	void contextLoads() {
	}

}
